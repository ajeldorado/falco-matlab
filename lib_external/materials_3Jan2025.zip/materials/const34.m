function [n]=const20(lam)
    % material with constant refractive index n=3.40
    % for example Si 
    n    = 3.4 + 0*lam;
end
