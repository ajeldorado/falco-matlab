function [n]=TiO2_Tobias(lam)
    % data from Tobias' ALD (269nm-684nm)
    data = csvread('TiO2_Tobias_ALD_TiO2_90C_betterFit.nnn',2);  % skip first 2 rows
    lams = data(:,1)./1000;              % first comumn is wavelength
    ns   = data(:,2);              % second comumn is refractive index
    n    = interp1(lams,ns,lam);   % interpolate query wavelength
end